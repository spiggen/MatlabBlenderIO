function bd = body()
bd = struct();
bd.is_body = true;
end